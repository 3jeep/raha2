import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart' show LatLng;

class MapViewPage extends StatefulWidget {
  final String serviceType;
  final String adminType;

  const MapViewPage({
    super.key,
    required this.serviceType,
    this.adminType = 'user',
  });

  @override
  State<MapViewPage> createState() => _MapViewPageState();
}

class _MapViewPageState extends State<MapViewPage> {
  // مفتاح خرائط جوجل الخاص بك
  final String googleApiKey = "AIzaSyDvEQmuL-cYhP0LE0Fbrmii6vci_8KUY2Q";
  
  WebViewController? _webController;
  LatLng? _userLocation;
  bool _isLoading = true;
  bool _locationError = false; 
  bool _showDetailsCard = true; 
  bool _isLocatingCurrent = false; 
  String _travelTime = "";
  String _travelDistance = "";

  List<Map<String, dynamic>> _sortedHandymen = [];
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _determinePosition();
  }

  String _getCleanServiceTitle(String rawType) {
    if (rawType.contains("سباك")) return "سباك";
    if (rawType.contains("تكييف")) return "فني تكييف";
    if (rawType.contains("توصيل")) return "توصيل طلبات";
    if (rawType.contains("ممرض")) return "تمريض منزلي";
    if (rawType.contains("غسالات")) return "فني غسالات";
    if (rawType.contains("نقاش")) return "نقاش (دهانات)";
    if (rawType.contains("ستالايت")) return "فني ستالايت";
    if (rawType.contains("مبلط")) return "مبلط سيراميك";
    if (rawType.contains("مساعد بناء")) return "مساعد بناء";
    if (rawType.contains("حلاق")) return "حلاق منزلي";
    if (rawType.contains("غسيل عربات")) return "غسيل سيارات";
    return rawType; 
  }

  Widget _buildLoadingScreen() {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'assets/images/logo.png',
              width: 140,
              height: 140,
              errorBuilder: (context, error, stackTrace) => 
                const Icon(Icons.handyman, size: 80, color: Colors.blue),
            ),
            const SizedBox(height: 30),
            const SizedBox(
              width: 200,
              child: LinearProgressIndicator(
                backgroundColor: Color(0xFFF1F5F9),
                valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
                minHeight: 6,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "جاري تحديد موقعك الدقيق عبر الـ GPS ...", 
              style: TextStyle(
                fontFamily: 'Aljazeera', 
                fontWeight: FontWeight.bold, 
                color: Colors.blueGrey
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLocationErrorScreen() {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.location_off_rounded, size: 80, color: Colors.orangeAccent),
              const SizedBox(height: 20),
              const Text(
                "عذراً، لم نتمكن من تحديد موقعك الفعلي",
                style: TextStyle(fontFamily: 'Aljazeera', fontWeight: FontWeight.bold, fontSize: 16),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10),
              const Text(
                "يرجى التأكد من تفعيل خدمة الـ GPS في هاتفك ومنح التطبيق صلاحية الوصول للموقع الدقيق لتتمكن من رؤية الخريطة.",
                style: TextStyle(fontFamily: 'Aljazeera', color: Colors.grey, fontSize: 13, height: 1.5),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),
              ElevatedButton.icon(
                onPressed: () {
                  setState(() {
                    _locationError = false;
                    _isLoading = true;
                  });
                  _determinePosition();
                },
                icon: const Icon(Icons.refresh_rounded, color: Colors.white),
                label: const Text("إعادة المحاولة الآن", style: TextStyle(fontFamily: 'Aljazeera', fontWeight: FontWeight.bold, color: Colors.white)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  String _getHtmlMapContent(LatLng userLoc, List<Map<String, dynamic>> handymen) {
    String handymenJson = jsonEncode(handymen);
    return '''
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <style>
        #map { height: 100vh; width: 100%; background-color: #ffffff; }
        body { margin: 0; padding: 0; overflow: hidden; }
    </style>
</head>
<body>
    <div id="map"></div>
    <script>
        let map;
        let directionsRenderer;
        let directionsService;
        let userMarker;
        const userPos = { lat: ${userLoc.latitude}, lng: ${userLoc.longitude} };

        function getEmojiForProfession(profession) {
            if (profession.includes("كهربائي")) return "⚡";
            if (profession.includes("سباك")) return "🪠";
            if (profession.includes("تكييف")) return "❄️";
            if (profession.includes("توصيل")) return "🛵";
            if (profession.includes("ممرض")) return "🩺";
            if (profession.includes("غسالات")) return "🧺";
            if (profession.includes("ميكانيكي")) return "🔧";
            if (profession.includes("عامل مساعد")) return "🧹";
            if (profession.includes("نقاش")) return "🎨";
            if (profession.includes("نجار")) return "🪚";
            if (profession.includes("ستالايت")) return "📡";
            if (profession.includes("مبلط")) return "🧱";
            if (profession.includes("حداد")) return "⛓️";
            if (profession.includes("بناء")) return "🏗️";
            if (profession.includes("مساعد بناء")) return "🪵";
            if (profession.includes("طباخ")) return "👨‍🍳";
            if (profession.includes("حلاق")) return "💈";
            if (profession.includes("غسيل عربات")) return "🚗";
            return "🛠️";
        }

        function createUserMarkerIcon() {
            const canvas = document.createElement('canvas');
            canvas.width = 70;
            canvas.height = 70;
            const ctx = canvas.getContext('2d');
            ctx.shadowColor = 'rgba(0, 0, 0, 0.25)';
            ctx.shadowBlur = 6;
            ctx.shadowOffsetY = 4;
            ctx.beginPath();
            ctx.arc(35, 35, 26, 0, 2 * Math.PI);
            ctx.fillStyle = '#1E88E5'; 
            ctx.fill();
            ctx.lineWidth = 3;
            ctx.strokeStyle = '#FFFFFF';
            ctx.stroke();
            ctx.shadowColor = 'transparent'; 
            ctx.fillStyle = '#FFFFFF';
            ctx.font = 'bold 15px Aljazeera, Arial, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('أنت', 35, 35);
            return canvas.toDataURL();
        }

        function createHandymanMarkerIcon(profession) {
            const emoji = getEmojiForProfession(profession);
            const canvas = document.createElement('canvas');
            canvas.width = 70;
            canvas.height = 70;
            const ctx = canvas.getContext('2d');
            ctx.shadowColor = 'rgba(0, 0, 0, 0.25)';
            ctx.shadowBlur = 6;
            ctx.shadowOffsetY = 4;
            ctx.beginPath();
            ctx.arc(35, 35, 24, 0, 2 * Math.PI);
            ctx.fillStyle = '#FFC107'; 
            ctx.fill();
            ctx.lineWidth = 3;
            ctx.strokeStyle = '#FFFFFF';
            ctx.stroke();
            ctx.shadowColor = 'transparent';
            ctx.font = '22px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(emoji, 35, 36);
            return canvas.toDataURL();
        }

        function initMap() {
            map = new google.maps.Map(document.getElementById('map'), {
                zoom: 14,
                center: userPos,
                disableDefaultUI: true,
                zoomControl: false,
                gestureHandling: 'greedy'
            });

            directionsService = new google.maps.DirectionsService();
            directionsRenderer = new google.maps.DirectionsRenderer({
                map: map,
                suppressMarkers: true,
                polylineOptions: { strokeColor: "#1E88E5", strokeWeight: 6 }
            });

            userMarker = new google.maps.Marker({
                position: userPos,
                map: map,
                title: "موقعي الحالي",
                icon: {
                    url: createUserMarkerIcon(),
                    size: new google.maps.Size(70, 70),
                    origin: new google.maps.Point(0, 0),
                    anchor: new google.maps.Point(35, 35)
                }
            });

            const handymen = $handymenJson;
            handymen.forEach((h, index) => {
                const marker = new google.maps.Marker({
                    position: { lat: h.lat, lng: h.lng },
                    map: map,
                    title: h.name,
                    icon: {
                        url: createHandymanMarkerIcon(h.profession),
                        size: new google.maps.Size(70, 70),
                        origin: new google.maps.Point(0, 0),
                        anchor: new google.maps.Point(35, 35)
                    }
                });
                
                marker.addListener('click', () => {
                    window.FlutterChannel.postMessage(JSON.stringify({index: index, data: h}));
                    calculateRoute(userMarker.getPosition(), { lat: h.lat, lng: h.lng });
                });
            });

            if (handymen.length > 0) {
                calculateRoute(userPos, { lat: handymen[0].lat, lng: handymen[0].lng });
            }
        }

        window.panToUserLocation = function(lat, lng) {
            const newPos = { lat: lat, lng: lng };
            if (userMarker) {
                userMarker.setPosition(newPos);
            }
            map.panTo(newPos);
            map.setZoom(15);
        };

        window.focusMarker = function(index) {
            const h = $handymenJson[index];
            const pos = { lat: h.lat, lng: h.lng };
            map.panTo(pos);
            calculateRoute(userMarker.getPosition(), pos);
        };

        function calculateRoute(origin, dest) {
            directionsService.route({
                origin: origin,
                destination: dest,
                travelMode: 'DRIVING'
            }, (response, status) => {
                if (status === 'OK') {
                    directionsRenderer.setDirections(response);
                    const leg = response.routes[0].legs[0];
                    window.DistanceChannel.postMessage(JSON.stringify({
                        distance: leg.distance.text,
                        duration: leg.duration.text
                    }));
                }
            });
        }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=$googleApiKey&callback=initMap" async defer></script>
</body>
</html>
''';
  }

  Future<void> _determinePosition() async {
    try {
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high
      );

      if (mounted) {
        setState(() {
          _userLocation = LatLng(position.latitude, position.longitude);
          _locationError = false;
        });
        _fetchHandymenFromFirestore();
      }
    } catch (e) {
      debugPrint("فشل جلب الـ GPS الحقيقي الدقيق: $e");
      if (mounted) {
        setState(() {
          _userLocation = null; 
          _locationError = true; 
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _goToCurrentLocation() async {
    setState(() => _isLocatingCurrent = true);
    try {
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high
      );
      LatLng currentLatLng = LatLng(position.latitude, position.longitude);
      setState(() {
        _userLocation = currentLatLng;
      });
      _webController?.runJavaScript("window.panToUserLocation(${position.latitude}, ${position.longitude})");
      _fetchHandymenFromFirestore();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("تعذر تحديث موقعك الفعلي الدقيق، يرجى تشغيل الـ GPS والضغط مجدداً", style: TextStyle(fontFamily: 'Aljazeera', fontSize: 12)),
          backgroundColor: Colors.redAccent,
        ),
      );
    } finally {
      setState(() => _isLocatingCurrent = false);
    }
  }

  void _fetchHandymenFromFirestore() async {
    if (_userLocation == null) return;

    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('handymen')
          .where('profession', isEqualTo: widget.serviceType)
          .where('isActive', isEqualTo: true)
          .get();

      List<Map<String, dynamic>> temp = [];
      for (var doc in snapshot.docs) {
        var data = doc.data();
        
        if (data['lat'] != null && data['lng'] != null) {
          double dist = Geolocator.distanceBetween(
              _userLocation!.latitude, _userLocation!.longitude, 
              data['lat'], data['lng']) / 1000;
          
          if (dist <= 13) {
            temp.add({
              'id': doc.id,
              'name': data['name'] ?? "حرفي راحة",
              'profession': data['profession'] ?? widget.serviceType,
              'phone': data['phone'] ?? "",
              'bio': data['bio'] ?? "",
              'locationName': data['locationName'] ?? "",
              'lat': data['lat'],
              'lng': data['lng'],
              'distance': dist
            });
          }
        }
      }
      
      temp.sort((a, b) => a['distance'].compareTo(b['distance']));
      
      if (!mounted) return;
      setState(() {
        _sortedHandymen = temp;
      });

      if (_webController != null) {
        _webController!.loadHtmlString(_getHtmlMapContent(_userLocation!, _sortedHandymen));
      } else {
        _initWebController();
      }
    } catch (e) {
      debugPrint("Firestore Error: $e");
      if (!mounted) return;
      setState(() => _isLoading = false);
    }
  }

  void _initWebController() {
    _webController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setUserAgent("Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36")
      ..addJavaScriptChannel('FlutterChannel', onMessageReceived: (msg) {
        final decoded = jsonDecode(msg.message);
        setState(() {
          _currentIndex = decoded['index'];
          _showDetailsCard = true; 
        });
      })
      ..addJavaScriptChannel('DistanceChannel', onMessageReceived: (msg) {
        final data = jsonDecode(msg.message);
        setState(() { 
          _travelDistance = data['distance']; 
          _travelTime = data['duration']; 
        });
      })
      ..loadHtmlString(_getHtmlMapContent(_userLocation!, _sortedHandymen));

    if (mounted) {
      setState(() => _isLoading = false);
    }
  }

  void _navigateToHandyman(int index) {
    if (_sortedHandymen.isEmpty) return;
    setState(() {
      _currentIndex = index;
      _travelTime = "";
      _travelDistance = "";
      _showDetailsCard = true; 
    });
    _webController?.runJavaScript("window.focusMarker($index)");
  }

  void _incrementCallAndLaunch(Map<String, dynamic> h) async {
    try {
      await FirebaseFirestore.instance.collection('handymen').doc(h['id']).update({
        'total_calls': FieldValue.increment(1)
      });
    } catch (e) {
      debugPrint("Error updating total_calls: $e");
    }
    launchUrl(Uri.parse("tel:${h['phone']}"));
  }

  Widget _btn(IconData icon, String label, Color col, VoidCallback onTap) {
    return ElevatedButton.icon(
      onPressed: onTap, 
      icon: Icon(icon, color: Colors.white, size: 18), 
      label: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'Aljazeera')), 
      style: ElevatedButton.styleFrom(
        backgroundColor: col, 
        padding: const EdgeInsets.symmetric(vertical: 12),
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))
      )
    );
  }

  Widget _buildHandymanDetailsCard(Map<String, dynamic> h) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 25),
      decoration: BoxDecoration(
        color: Colors.white, 
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 20,
            offset: const Offset(0, -4),
          )
        ],
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _navButton("السابق", Icons.arrow_back_ios_new, _currentIndex > 0 ? () => _navigateToHandyman(_currentIndex - 1) : null),
              
              Text(
                "${_currentIndex + 1} من ${_sortedHandymen.length} (الأقرب)",
                style: const TextStyle(fontFamily: 'Aljazeera', fontWeight: FontWeight.bold, color: Colors.blueGrey, fontSize: 13),
              ),

              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _navButton("التالي", Icons.arrow_forward_ios, _currentIndex < _sortedHandymen.length - 1 ? () => _navigateToHandyman(_currentIndex + 1) : null, isNext: true),
                  const SizedBox(width: 12),
                  GestureDetector(
                    onTap: () => setState(() => _showDetailsCard = false),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: Colors.grey[100],
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.close, size: 18, color: Colors.grey),
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 15),
          
          Text(h['name'], style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, fontFamily: 'Aljazeera')),
          const SizedBox(height: 5),
          
          Row(
            mainAxisAlignment: MainAxisAlignment.center, 
            children: [
              Text("📍 الحي: ${h['locationName']}", style: const TextStyle(color: Colors.blue, fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'Aljazeera')),
              const SizedBox(width: 15),
              Text("🎯 يبعد عنك ${h['distance'].toStringAsFixed(1)} كم", style: const TextStyle(color: Colors.grey, fontSize: 12, fontFamily: 'Aljazeera')),
            ],
          ),
          
          if (_travelTime.isNotEmpty) 
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text("🚗 يستغرق بالطريق: $_travelDistance ($_travelTime)", 
                style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'Aljazeera')),
            ),
          
          if (h['bio'].toString().isNotEmpty) ...[
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8.0),
              child: Divider(color: Color(0xFFF1F5F9)),
            ),
            Text(h['bio'], style: const TextStyle(fontStyle: FontStyle.italic, color: Colors.black87, fontSize: 13), textAlign: TextAlign.center),
          ],
          
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 12.0),
            child: Divider(color: Color(0xFFF1F5F9)),
          ),
          
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly, 
            children: [
              Expanded(child: _btn(Icons.phone, "اتصال سلكي", Colors.green, () => _incrementCallAndLaunch(h))),
              const SizedBox(width: 12),
              Expanded(child: _btn(Icons.message, "واتساب", Colors.blue, () => launchUrl(Uri.parse("https://wa.me/${h['phone']}")))),
            ],
          ),
        ],
      ),
    );
  }

  Widget _navButton(String label, IconData icon, VoidCallback? onTap, {bool isNext = false}) {
    final bool isDisabled = onTap == null;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: isDisabled ? Colors.grey[100] : (isNext ? Colors.blue.withOpacity(0.1) : Colors.grey[200]),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: isNext 
            ? [
                Text(label, style: TextStyle(color: isDisabled ? Colors.grey : Colors.blue, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'Aljazeera')),
                const SizedBox(width: 4),
                Icon(icon, size: 12, color: isDisabled ? Colors.grey : Colors.blue),
              ]
            : [
                Icon(icon, size: 12, color: isDisabled ? Colors.grey : Colors.black87),
                const SizedBox(width: 4),
                Text(label, style: TextStyle(color: isDisabled ? Colors.grey : Colors.black87, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'Aljazeera')),
              ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_locationError) {
      return _buildLocationErrorScreen(); 
    }

    if (_isLoading || _webController == null || _userLocation == null) {
      return _buildLoadingScreen(); 
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "خريطة ${_getCleanServiceTitle(widget.serviceType)}", 
          style: const TextStyle(fontWeight: FontWeight.bold, fontFamily: 'Aljazeera', fontSize: 16)
        ),
        centerTitle: true,
      ),
      body: _sortedHandymen.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Text(
                  "لا يوجد حرفيون متاحون من نوع (${_getCleanServiceTitle(widget.serviceType)}) حالياً في محيط 13 كم.",
                  style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.grey, fontFamily: 'Aljazeera'),
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : Stack(
              children: [
                WebViewWidget(controller: _webController!),

                Positioned(
                  bottom: _showDetailsCard ? 330 : 30, 
                  left: 20,
                  child: FloatingActionButton(
                    onPressed: _isLocatingCurrent ? null : _goToCurrentLocation,
                    backgroundColor: Colors.white,
                    mini: true,
                    elevation: 6,
                    shape: const CircleBorder(),
                    child: _isLocatingCurrent 
                        ? const SizedBox(
                            width: 18, 
                            height: 18, 
                            child: CircularProgressIndicator(strokeWidth: 2, valueColor: AlwaysStoppedAnimation<Color>(Colors.blue)),
                          )
                        : const Icon(Icons.my_location, color: Colors.blue, size: 20),
                  ),
                ),

                if (_showDetailsCard)
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: _buildHandymanDetailsCard(_sortedHandymen[_currentIndex]),
                  ),
              ],
            ),
    );
  }
}
