import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'app_constants.dart';

class ManageHandymanPage extends StatefulWidget {
  const ManageHandymanPage({super.key});

  @override
  State<ManageHandymanPage> createState() => _ManageHandymanPageState();
}

class _ManageHandymanPageState extends State<ManageHandymanPage> {
  final user = FirebaseAuth.instance.currentUser;
  bool _isLoading = false;

  // الحقول المطلوبة للحفظ
  String _selectedProfession = AppConstants.professionsList[0];
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _bioController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  double? _lat, _lng;
  String? _editingId;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFB),
      appBar: AppBar(
        title: const Text("لوحة تحكم الحرفيين", style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
        actions: [
          IconButton(onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout, color: Colors.red))
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            _buildHeader(),
            const SizedBox(height: 15),
            _buildVerifyBanner(),
            const SizedBox(height: 20),
            _buildMyServicesList(),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddServiceSheet(),
        backgroundColor: Colors.black,
        label: const Text("إضافة حرفة جديدة", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        icon: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  Widget _buildHeader() {
    bool isGoogleUser = user?.providerData.any((p) => p.providerId == 'google.com') ?? false;
    String? photoUrl = user?.photoURL;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(25), border: Border.all(color: Colors.grey.shade100)),
      child: Row(
        children: [
          CircleAvatar(
            radius: 25,
            backgroundColor: Colors.black,
            backgroundImage: photoUrl != null ? NetworkImage(photoUrl) : null,
            child: photoUrl == null ? Text(user?.displayName?[0] ?? "U", style: const TextStyle(color: Colors.white)) : null,
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user?.displayName ?? "مستخدم راحة", style: const TextStyle(fontWeight: FontWeight.w900)),
                const Text("تحكم بظهورك على الخريطة", style: TextStyle(fontSize: 10, color: Colors.grey)),
                if (isGoogleUser && photoUrl != null)
                  const Padding(
                    padding: EdgeInsets.only(top: 4),
                    child: Text("لتغيير صورتك، قم بتغييرها في حساب Google", style: TextStyle(fontSize: 8, color: Colors.blue, fontWeight: FontWeight.bold)),
                  ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildVerifyBanner() {
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('whatsapp').doc('contact').snapshots(),
      builder: (context, snapshot) {
        String whatsappNum = "";
        if (snapshot.hasData && snapshot.data!.exists) {
          var data = snapshot.data!.data() as Map<String, dynamic>;
          whatsappNum = data['contact'] ?? data['number'] ?? "";
        }
        
        return Container(
          width: double.infinity,
          decoration: BoxDecoration(color: Colors.blue.shade50, borderRadius: BorderRadius.circular(20)),
          child: InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: () async {
              if (whatsappNum.isNotEmpty) {
                final Uri url = Uri.parse("https://wa.me/$whatsappNum?text=أريد توثيق حرفتي في تطبيق راحة");
                if (await canLaunchUrl(url)) {
                  await launchUrl(url, mode: LaunchMode.externalApplication);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("تعذر فتح تطبيق واتساب")));
                }
              }
            },
            child: Padding(
              padding: const EdgeInsets.all(15),
              child: Row(
                children: [
                  const Icon(Icons.verified, color: Colors.blue),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Text(
                      "تواصل معنا واتساب لتوثيق حرفتك",
                      style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold, fontSize: 12),
                    ),
                  ),
                  const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.blue),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildMyServicesList() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('handymen').where('uid', isEqualTo: user?.uid).snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const CircularProgressIndicator();
        var docs = snapshot.data!.docs;
        
        if (docs.isEmpty) return const Center(child: Text("لا توجد حرف مسجلة حالياً", style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)));

        return ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: docs.length,
          itemBuilder: (context, index) {
            var s = docs[index].data() as Map<String, dynamic>;
            String docId = docs[index].id;
            bool isActive = s['isActive'] ?? true;
            bool isVerified = s['isVerified'] ?? false;
            int calls = s['total_calls'] ?? 0;

            return Container(
              margin: const EdgeInsets.only(bottom: 15),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(30), border: Border.all(color: Colors.grey.shade100)),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(s['profession'], style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                              if (isVerified) ...[
                                const SizedBox(width: 5),
                                const Icon(Icons.verified, color: Colors.blue, size: 18),
                              ]
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: List.generate(5, (i) => Icon(Icons.star, color: Colors.amber, size: 14)),
                          ),
                          const SizedBox(height: 4),
                          Text("📍 ${s['locationName']}", style: const TextStyle(fontSize: 11, color: Colors.blue, fontWeight: FontWeight.bold)),
                        ],
                      ),
                      Row(
                        children: [
                          IconButton(onPressed: () => _initEdit(docId, s), icon: const Icon(Icons.edit, color: Colors.blue, size: 20)),
                          IconButton(onPressed: () => _deleteService(docId), icon: const Icon(Icons.delete, color: Colors.red, size: 20)),
                        ],
                      )
                    ],
                  ),
                  const Divider(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("📞 عدد مرات التواصل: $calls", style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.grey)),
                      SizedBox(
                        width: 150,
                        child: SwitchListTile(
                          contentPadding: EdgeInsets.zero,
                          title: Text(isActive ? "متاح" : "مشغول", style: TextStyle(fontWeight: FontWeight.w900, fontSize: 11, color: isActive ? Colors.green : Colors.grey)),
                          value: isActive,
                          activeColor: Colors.green,
                          onChanged: (val) => FirebaseFirestore.instance.collection('handymen').doc(docId).update({'isActive': val}),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _showAddServiceSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
      builder: (context) => StatefulBuilder(
        builder: (context, setSheetState) => Container(
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom, left: 20, right: 20, top: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_editingId == null ? "إضافة حرفة جديدة" : "تعديل البيانات", style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
              const SizedBox(height: 20),
              DropdownButtonFormField(
                value: _selectedProfession,
                items: AppConstants.professionsList.map((p) => DropdownMenuItem(value: p, child: Text(p))).toList(),
                onChanged: (val) => setSheetState(() => _selectedProfession = val!),
                decoration: const InputDecoration(labelText: "نوع الحرفة"),
              ),
              TextField(controller: _locationController, decoration: const InputDecoration(labelText: "اسم المنطقة (الحي)")),
              const SizedBox(height: 15),
              ElevatedButton.icon(
                onPressed: () async {
                  var pos = await Geolocator.getCurrentPosition();
                  setSheetState(() { _lat = pos.latitude; _lng = pos.longitude; });
                },
                icon: Icon(Icons.my_location, color: _lat != null ? Colors.green : Colors.white),
                label: Text(_lat != null ? "تم تحديد الموقع ✅" : "تحديث موقعي على الخريطة"),
                style: ElevatedButton.styleFrom(backgroundColor: _lat != null ? Colors.green.shade50 : Colors.blue, foregroundColor: _lat != null ? Colors.green : Colors.white),
              ),
              TextField(controller: _phoneController, decoration: const InputDecoration(labelText: "رقم الهاتف"), keyboardType: TextInputType.phone),
              TextField(controller: _bioController, decoration: const InputDecoration(labelText: "نبذة عن خبرتك"), maxLines: 2),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => _saveService(),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.black, minimumSize: const Size(double.infinity, 50)),
                child: const Text("حفظ ونشر الحرفة", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  void _saveService() async {
    if (_lat == null || _locationController.text.isEmpty) return;

    var data = {
      'uid': user?.uid,
      'name': user?.displayName ?? "حرفي راحة",
      'profession': _selectedProfession,
      'phone': _phoneController.text,
      'bio': _bioController.text,
      'locationName': _locationController.text,
      'lat': _lat,
      'lng': _lng,
      'photoUrl': user?.photoURL ?? "", // حفظ رابط الصورة في كل حرفة للسهولة
      'updatedAt': FieldValue.serverTimestamp(),
    };

    if (_editingId == null) {
      await FirebaseFirestore.instance.collection('handymen').add({
        ...data,
        'isVerified': false,
        'isActive': true,
        'rating': 5.0,
        'total_calls': 0,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } else {
      await FirebaseFirestore.instance.collection('handymen').doc(_editingId).update(data);
    }
    Navigator.pop(context);
    _resetForm();
  }

  void _initEdit(String id, Map<String, dynamic> s) {
    _editingId = id;
    _selectedProfession = s['profession'];
    _phoneController.text = s['phone'];
    _bioController.text = s['bio'] ?? "";
    _locationController.text = s['locationName'] ?? "";
    _lat = s['lat'];
    _lng = s['lng'];
    _showAddServiceSheet();
  }

  void _resetForm() {
    _editingId = null;
    _phoneController.clear();
    _bioController.clear();
    _locationController.clear();
    _lat = null; _lng = null;
  }

  void _deleteService(String id) {
     FirebaseFirestore.instance.collection('handymen').doc(id).delete();
  }
}
